O CPU est� concluido

Comparado com o backup anterior, todas as liga��es est�o feitas. Apenas est� a dar um WARNING:

Bus 'XLXN_40(7:0)' is connected to source pins and/or I/O markers, but not connected to any load pins or I/O marker


Com este backup, fico com O CPU quase concluido

Falta acabar o controlador e liga-lo a perif�ricos

----------------------------------------------------------

O controlador est� quase acabado

falta 4 fun��es:

INT addr | STI | CLI | INT

17/05/2022 22:02

----------------------------------------------------------
-O WARNING no CPU foi resolvido
-A schematic do dispositivo 115 foi criada. 
-O seu simbolo tamb�m.
-O simbolo tem o nome: dispo115

18/05/2022 16:04

----------------------------------------------------------

Arranjei o controlador que n�o tinha os ficheiros todos e mudei o nome para CONTROLADOR2


18/05/2022 8:17

----------------------------------------------------------
O programa j� foi colocado na ROM:

Bit 0 - 00924000000001000021443CC30B9B13
Bit 1 - 0011800000000C0000204435A53AC813
Bit 2 - 0021C000000013800021222F64A30D23
Bit 3 - 0010000000003800000188102E00C317
Bit 4 - 0092000000002A800000661D519C0216
Bit 5 - 00000000000000800000020A28080012
Bit 6 - 00000000000002000000200020A80012
Bit 7 - 00400000000000000000000000022852
Cada bit corresponde a uma c�lula a azul do excel.

19/05/2022 12:12
---------------------------------------------------------
Mudei a schematic do 115 

19/05/2022 19:03
---------------------------------------------------------
Dia 21/5

Adicionei o dispositivo 52 
---------------------------------------------------------
Dia 27/05

Corrigi ALUflags para bus ler FLAGS(1), FLAGS(0), ...
Corrigi dispo 52 no mesmo erro do de cima
Fiz teste CL_8 e bufee - tudo bem nestes componentes
---------------------------------------------------------
Adicionei as fun��es INT address | STI | CTI | 
Adicionei as flags de ST(student) e interrupt 

30/05/2022 14:41
---------------------------------------------------------
Criei o simbolo do NCCPU e do CONTROLADOR2
Liguei partialmente ambos os componentes no ficheiro: CPU.sch


30/05/2022 18:38
---------------------------------------------------------
Liguei partialmente ambos os componentes no ficheiro: CPU.sch
Tamb�m liguei algumas entradas do NCCPu(ZA, IC, CD) and ground, dado que o controlador n�o as usou


30/05/2022 18:55
---------------------------------------------------------
Arranjei as vari�veis do CONTROLADOR2
Pus labels nas  fun��es do CONTROLADOR2
Liguei o RAMROMenable ao CONTROLBUS
Liguei o OPCODE e as FLAGS do CPU ao CONTROLADOR2
Liguei o INTF a um tristate, que quando est� ativo mete o valor 00001000 no DATABUS


04/06/2022 00:53
---------------------------------------------------------
Tornei no schematic CPU a tar do controlador BIdirecional.
No dispositivo 84 mudei o nome dos fios que ligam ao BUS para n�o dar erro.
Criei simbolo CPU, dispo84 e dispo52
Criei o schematic microcontrolador.sch. Ai conectei o CPU com os dispo e a ramrom.
Existe um warnign que n�o consegui corrigir:
WARNING:DesignEntry:220 - microcontrolador.sch Bus 'XLXN_7(7:0)' is connected to too many source pins and/or I/O markers. A 'Wired OR' connection will be used.


04/06/2022 16:13
--------------------------------------------------------------
Etiquetas no microcontrolador.sch para os testes
test para microcontrolador criado



04/06/2022 18:46
-------------------------------------------------------------
O problema dos ANDS, XORS e ORS da ALU, onde bits de entrada n�o correspondiam aos de saida, j� foi resolvido


09/06/2022 18:32
----------------------------------------------------------

O teste do componente CL_8(TMP inside ALU) foi feito e correu bem.
N�o estava bem porque os bits do Din, Dout e Qout em vez de tarem num fio:(7, 6, 5, 4, ...), Estavam (0, 1, 2, 3, 4 ...)
Assim causando erro.

O teste da ALU tamb�m foi feito. N�o sei se est� bem feito ou n�o.

09/06/2022 19:03
-----------------------------------------------------------
Nesta vers�o, mudei os registors A, B, C, D, MAR, PC para a mesma vers�o que o CL_8. 
Mudei estes registos pela mesma raz�o que mudei o CL_8.

Quando fiz o teste final, ainda n�o estava a dar bem. 

09/06/2022 19:33
-------------------------------------------------------------
Nesta ver�o, mudei o VCC do ALUFLAGS para GND.
Tiver, por causa disso, de refazer alguns circuitos da ALU, NCCPU e CPU.

O teste comtinua a n�o dar. N�o � porque n�o falta RC no controlador?

10/06/2022 11:46
-------------------------------------------------------------
Retirei ficheiros, testes e dei clean projetcs files.

11/06/2022 15:31
--------------------------------------------------------------
Tirei o componente ALUflags e criei testes para o IR e SP

11/06/2022 16 54
--------------------------------------------------------------
Todos os testes foram feitos e todos correram bem
N�o fizemos do flag rigistor e do microprocessador n�o correram bem.

11/06/2022 19:52
